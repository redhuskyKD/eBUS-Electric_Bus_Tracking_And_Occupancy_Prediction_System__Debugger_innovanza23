package com.example.electricbus.models;

import com.google.android.gms.maps.model.Marker;

public class Bus {
    public String Id;
    public double latitude,longitude;
    public Marker marker;
}
