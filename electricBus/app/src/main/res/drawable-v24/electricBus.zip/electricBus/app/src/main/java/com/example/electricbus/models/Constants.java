package com.example.electricbus.models;

public class Constants {

public static final String KEY_COLLECTION_USER= "busesDetail";
public static final String KEY_BUS_ID="keyBusId";
public static final String busId= "busId";
public static final String password= "password";
public static final String addressLine="AddressLine";
public static final String latitude="latitude";
public static final String longitude="longitude";
public static final String adminArea="adminArea";
public static final String featureName="featureName";
public static final String locality="locality";
public static final String date="date";


}
